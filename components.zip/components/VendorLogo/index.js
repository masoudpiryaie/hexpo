export { default } from "./VendorLogo";
