import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const ReturnedProduct = () => {
    return (
        <View>
            <Text>ReturnedProduct</Text>
        </View>
    )
}

export default ReturnedProduct