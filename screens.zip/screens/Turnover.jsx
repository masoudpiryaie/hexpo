import { View, Text } from 'react-native'
import React from 'react'

const Turnover = () => {
    return (
        <View>
            <Text>Turnover</Text>
        </View>
    )
}

export default Turnover