import { View, Text } from 'react-native'
import React from 'react'

const ShopContract = () => {
    return (
        <View>
            <Text>ShopContract</Text>
        </View>
    )
}

export default ShopContract