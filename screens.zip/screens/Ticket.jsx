import { View, Text } from 'react-native'
import React from 'react'

const Ticket = () => {
    return (
        <View>
            <Text>Ticket</Text>
        </View>
    )
}

export default Ticket