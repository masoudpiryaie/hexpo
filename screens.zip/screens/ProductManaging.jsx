import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const ProductManaging = () => {
  return (
    <View>
      <Text>ProductManaging</Text>
    </View>
  )
}

export default ProductManaging