export { default } from "./IdCardUpload";
