export { default } from "./BankAcountInfo";
