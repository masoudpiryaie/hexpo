import { View, Text } from 'react-native'
import React from 'react'

const SalesReport = () => {
    return (
        <View>
            <Text>SalesReport</Text>
        </View>
    )
}

export default SalesReport