import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const MyCampaign = () => {
    return (
        <View>
            <Text>MyCampaign</Text>
        </View>
    )
}

export default MyCampaign