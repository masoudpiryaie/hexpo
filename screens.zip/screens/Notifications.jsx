import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const Notifications = () => {
    return (
        <View>
            <Text>Notifications</Text>
        </View>
    )
}

export default Notifications
