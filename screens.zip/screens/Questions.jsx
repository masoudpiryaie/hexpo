import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const Questions = () => {
    return (
        <View>
            <Text>Questions</Text>
        </View>
    )
}

export default Questions