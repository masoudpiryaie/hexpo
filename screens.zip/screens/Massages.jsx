import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const Massages = () => {
    return (
        <View>
            <Text>Massages</Text>
        </View>
    )
}

export default Massages