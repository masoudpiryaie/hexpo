import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const BuySubscribtion = () => {
    return (
        <View>
            <Text>BuySubscribtion</Text>
        </View>
    )
}

export default BuySubscribtion

