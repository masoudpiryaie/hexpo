import { View, Text } from 'react-native'
import React from 'react'

const Info = () => {
    return (
        <View>
            <Text>Info</Text>
        </View>
    )
}

export default Info